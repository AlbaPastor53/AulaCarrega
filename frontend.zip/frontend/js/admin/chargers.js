/*
  ================================================================
  PUNTS DE CÀRREGA · COM FUNCIONA AQUEST FITXER
  ================================================================

  Aquest fitxer conté tota la lògica de la pàgina chargers.html.

  FLUX GENERAL
  1. admin.js confirma que l'usuari és Admin i posa window.adminReady.
  2. Al final del fitxer, si adminReady és true, s'executa init().
  3. init() connecta tots els esdeveniments i crida loadChargers().
  4. loadChargers() demana la llista a l'API i crida render().
  5. render() calcula els comptadors, filtra i pinta la taula.

  PARTS DEL FITXER
  - STATUS: etiqueta i classe de badge per cada estat.
  - escapeHtml(): evita que el text de la base de dades s'interpreti com HTML.
  - showMessage(): missatges generals a l'element #message.
  - showChargerModalMessage(): missatges dins del modal.
  - render(): actualitza els comptadors i pinta les files de #chargersTable.
  - loadChargers(): GET /chargers?limit=100 i actualitza #lastUpdated.
  - init(): registra tots els esdeveniments.

  ACCIONS DE L'USUARI
  - Filtrar: escriu a #search o canvia #filterStatus.
  - Crear: #openChargerModal obre #chargerModal; en enviar #chargerForm
    es fa POST /chargers amb { name, status, isActive }.
  - Canviar estat: change en un select [data-action="status"] fa
    PATCH /chargers/:id amb { status }.
  - Activar/desactivar: click en un botó [data-action="toggle"] fa
    PATCH /chargers/:id amb { isActive }.
  - Eliminar: click en un botó [data-action="delete"] demana confirmació
    i fa DELETE /chargers/:id.

  DESPRÉS DE CADA CANVI
  - Es mostra un missatge a #message.
  - Es crida loadChargers() per tornar a llegir les dades reals de l'API.
  - Així la taula sempre mostra el que hi ha guardat a MongoDB.

  IMPORTANT
  - L'HTML i el JS es comuniquen pels IDs i pels atributs
    data-action i data-id.
  - Si canvies un ID a chargers.html, canvia'l també aquí.
  - ApiService.api() afegeix el token de sessió automàticament.
  ================================================================
*/
import { ApiService } from "../api.js";

const STATUS = {
  Available: { label: 'Operatiu', badge: 'badge--available' },
  Maintenance: { label: 'Manteniment', badge: 'badge--maintenance' },
  Broken: { label: 'Averiat', badge: 'badge--broken' }
};

let chargers = [];

// Converteix caràcters especials per poder mostrar-los sense problemes a la taula.
const escapeHtml = (value) => {
  const symbols = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  };

  return String(value ?? '').replace(/[&<>"']/g, (char) => symbols[char]);
};

const showMessage = (text, ok = true) => {
  const message = document.getElementById('message');
  message.textContent = text;
  message.style.color = ok ? 'var(--accent)' : '#ff9aa2';
};

const showChargerModalMessage = (text, ok = true) => {
  const message = document.getElementById('chargerModalMessage');
  message.textContent = text;
  message.style.color = ok ? 'var(--accent)' : '#ff9aa2';
};

const render = () => {
  const search = document.getElementById('search').value.trim().toLowerCase();
  const status = document.getElementById('filterStatus').value;

  document.getElementById('statTotal').textContent = chargers.length;
  document.getElementById('statAvailable').textContent =
    chargers.filter((charger) => charger.status === 'Available').length;
  document.getElementById('statMaintenance').textContent =
    chargers.filter((charger) => charger.status === 'Maintenance').length;
  document.getElementById('statBroken').textContent =
    chargers.filter((charger) => charger.status === 'Broken').length;

  const visibleChargers = chargers.filter((charger) => {
    const matchesName = charger.name.toLowerCase().includes(search);
    const matchesStatus = status === '' || charger.status === status;

    return matchesName && matchesStatus;
  });

  document.getElementById('listSummary').textContent =
    `${visibleChargers.length} carregador${visibleChargers.length === 1 ? '' : 's'}`;

  if (visibleChargers.length === 0) {
    document.getElementById('chargersTable').innerHTML =
      '<tr><td colspan="4" class="empty-state">No hi ha carregadors disponibles.</td></tr>';
    return;
  }

  document.getElementById('chargersTable').innerHTML = visibleChargers.map((charger) => {
    const statusInfo = STATUS[charger.status] || STATUS.Available;

    const options = Object.keys(STATUS).map((value) => {
      const selected = value === charger.status ? 'selected' : '';
      return `<option value="${value}" ${selected}>${STATUS[value].label}</option>`;
    }).join('');

    return `
      <tr>
        <td>
          <div class="point">
            <span class="point-icon" aria-hidden="true">ϟ</span>
            ${escapeHtml(charger.name)}
          </div>
        </td>
        <td><span class="badge ${statusInfo.badge}">${statusInfo.label}</span></td>
        <td>${charger.isActive ? 'Sí' : 'No'}</td>
        <td>
          <div class="actions">
            <select data-action="status" data-id="${charger._id}" aria-label="Estat">
              ${options}
            </select>
            <button class="button button--secondary" data-action="toggle" data-id="${charger._id}">
              ${charger.isActive ? 'Desactivar' : 'Activar'}
            </button>
            <button class="button button--secondary" data-action="delete" data-id="${charger._id}">
              Eliminar
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');
};

const loadChargers = async () => {
  try {
    document.getElementById('lastUpdated').textContent = 'Carregant…';

    const response = await ApiService.api('/chargers?limit=100');
    chargers = response.data || [];

    render();
    document.getElementById('lastUpdated').textContent =
      `Actualitzat a les ${new Date().toLocaleTimeString('ca-ES')}`;
  } catch (error) {
    document.getElementById('chargersTable').innerHTML =
      `<tr><td colspan="4" class="empty-state">${escapeHtml(error.message)}</td></tr>`;
    document.getElementById('lastUpdated').textContent = 'Error de connexió';
  }
};

const init = () => {
  // Obrir i tancar la finestra de creació.
  document.getElementById('openChargerModal').addEventListener('click', () => {
    document.getElementById('chargerForm').reset();
    showChargerModalMessage('');
    document.getElementById('chargerModal').showModal();
  });

  document.getElementById('cancelChargerModal').addEventListener('click', () => {
    document.getElementById('chargerModal').close();
  });

  // Crear un carregador
  document.getElementById('chargerForm').addEventListener('submit', async (event) => {
    event.preventDefault();

    try {
      await ApiService.api('/chargers', {
        method: 'POST',
        body: JSON.stringify({
          name: document.getElementById('name').value.trim(),
          status: document.getElementById('newStatus').value,
          isActive: document.getElementById('newActive').checked
        })
      });

      document.getElementById('chargerModal').close();
      document.getElementById('chargerForm').reset();
      showMessage('Carregador creat correctament.');
      await loadChargers();
    } catch (error) {
      showChargerModalMessage(error.message, false);
    }
  });

  // Activar, desactivar o eliminar un carregador
  document.getElementById('chargersTable').addEventListener('click', async (event) => {
    const button = event.target.closest('button[data-action]');
    if (!button) return;

    const charger = chargers.find((item) => item._id === button.dataset.id);
    if (!charger) return;

    try {
      if (button.dataset.action === 'toggle') {
        await ApiService.api(`/chargers/${charger._id}`, {
          method: 'PATCH',
          body: JSON.stringify({ isActive: !charger.isActive })
        });
      }

      if (button.dataset.action === 'delete') {
        if (!confirm(`Segur que vols eliminar el carregador "${charger.name}"?`)) return;
        await ApiService.api(`/chargers/${charger._id}`, { method: 'DELETE' });
      }

      showMessage('Canvis guardats.');
      await loadChargers();
    } catch (error) {
      showMessage(error.message, false);
    }
  });

  // Canviar l'estat des del desplegable de cada fila
  document.getElementById('chargersTable').addEventListener('change', async (event) => {
    const select = event.target.closest('select[data-action="status"]');
    if (!select) return;

    try {
      await ApiService.api(`/chargers/${select.dataset.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ status: select.value })
      });

      showMessage('Estat actualitzat.');
      await loadChargers();
    } catch (error) {
      showMessage(error.message, false);
    }
  });

  document.getElementById('refresh').addEventListener('click', loadChargers);
  document.getElementById('search').addEventListener('input', render);
  document.getElementById('filterStatus').addEventListener('change', render);

  loadChargers();
};

if (window.adminReady) {
  init();
}
