/*
  FITXER: js/auth.js
  RESPONSABILITAT:
    Gestionar la sessió de l'usuari al navegador i protegir les pàgines.

  A TENIR EN COMPTE:
    - Desa el token i les dades de l'usuari a localStorage després del login.
    - Funcions suggerides:
        saveSession(token, user), getToken(), getUser(),
        isLoggedIn(), isAdmin(), logout().
    - protectPage(): si no hi ha sessió, redirigeix a pages/login.html.
    - protectAdminPage(): a més, comprova que role === 'Admin'.
    - No desar mai la contrasenya.
    - logout() ha d'esborrar token i usuari i tornar al login.
*/
